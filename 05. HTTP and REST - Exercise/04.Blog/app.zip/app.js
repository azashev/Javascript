function attachEvents() {
    const posts = document.getElementById('posts');
    const btnLoadPosts = document.getElementById('btnLoadPosts');
    const btnViewPost = document.getElementById('btnViewPost');
    const postH1 = document.getElementById('post-title');
    const postBody = document.getElementById('post-body');
    const postComments = document.getElementById('post-comments');
    const BASE_URL = 'http://localhost:3030/jsonstore/blog/';

    let postsObj = {};
    btnLoadPosts.addEventListener('click', loadPosts);
    btnViewPost.addEventListener('click', view);

    async function loadPosts(e) {
        e.preventDefault();
        try {
            const response = await fetch(`${BASE_URL}posts`);
            if (!response.ok) {
                throw new Error(`${response.status} ${response.statusText}`);
            }
            const data = await response.json();
            Object.keys(data).forEach((key) => {
                const title = data[key].title;
                const optionElement = document.createElement('option');
                optionElement.value = key;
                optionElement.text = data[key].title;
                posts.appendChild(optionElement);

                postsObj[title] = { postId: data[key].id, postContent: data[key].body };
                
            });
        } catch (error) {
            // TO DO
        }
    }

    async function view(e) {
        e.preventDefault();
        try {
            const selectedPost = posts.options[posts.selectedIndex];
            const currentPostId = postsObj[selectedPost.text].postId;
            postComments.textContent = '';

            postH1.textContent = selectedPost.text;
            postBody.textContent = postsObj[selectedPost.text].postContent;

            const response = await fetch(`${BASE_URL}comments`);
            if (!response.ok) {
                throw new Error(`${response.status} ${response.statusText}`);
            }
            const data = await response.json();
            Object.values(data)
            .filter((x) => x.postId === currentPostId)
            .forEach((comment) => {
                const li = document.createElement('li');
                li.textContent = comment.text;
                postComments.appendChild(li);
            });
        } catch (error) {
            
        }
    }
}

attachEvents();
























// function attachEvents() {
//     let postObject = {};
  
//     const loadButtonElement = document.getElementById("btnLoadPosts");
//     const postMenu = document.getElementById("posts");
//     const viewButtonElement = document.getElementById("btnViewPost");
//     const postTitle = document.getElementById("post-title");
//     const postBody = document.getElementById("post-body");
//     const ulComments = document.getElementById("post-comments");
//     loadButtonElement.addEventListener("click", loadPosts);
//     viewButtonElement.addEventListener("click", viewPosts);
  
//     async function loadPosts() {
//       const response = await fetch("http://localhost:3030/jsonstore/blog/posts");
//       const data = await response.json();
//       Object.keys(data).forEach((key) => {
//         const optionElement = document.createElement("option");
//         optionElement.value = key;
//         debugger;
//         const title = data[key].title;
//         optionElement.text = data[key].title;
//         postObject[title] = { postId: data[key].id, content: data[key].body };
//         postMenu.appendChild(optionElement);
//       });
//     }
  
//     async function viewPosts() {
//       const response = await fetch(
//         "http://localhost:3030/jsonstore/blog/comments"
//       );
//       const data = await response.json();
//       const selectedOption = postMenu.options[postMenu.selectedIndex];
//       postTitle.textContent = selectedOption.text;
//       postBody.textContent = postObject[selectedOption.text].content;
      
//       Object.keys(data)
//         .filter(
//           (key) => data[key].postId === postObject[selectedOption.text].postId
//         )
//         .forEach((key) => {
//           const liElement = document.createElement("li");
//           liElement.textContent = data[key].text;
//           ulComments.appendChild(liElement);
//         });
//     }
//   }
  
//   attachEvents();
